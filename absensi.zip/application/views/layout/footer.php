			<!-- footer start-->
			<footer class="footer">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-6 footer-copyright">
							<p class="mb-0">Copyright 2021-22 © Tim Dev Kominfo All rights reserved.</p>
						</div>

					</div>
				</div>
			</footer>
			</div>
			</div>

			<!-- feather icon js-->
			<script src="<?= base_url('assets/backend') ?>/js/icons/feather-icon/feather.min.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/icons/feather-icon/feather-icon.js"></script>
			<!-- Sidebar jquery-->
			<script src="<?= base_url('assets/backend') ?>/js/sidebar-menu.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/config.js"></script>
			<!-- Bootstrap js-->
			<script src="<?= base_url('assets/backend') ?>/js/bootstrap/popper.min.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/bootstrap/bootstrap.min.js"></script>
			<!-- Plugins JS start-->
			<script src="<?= base_url('assets/backend') ?>/js/prism/prism.min.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/clipboard/clipboard.min.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/custom-card/custom-card.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/tooltip-init.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/datatable/datatables/jquery.dataTables.min.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/datatable/datatables/datatable.custom.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/sweet-alert/sweetalert2.all.min.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/sweet-alert/app.js"></script>
			<!-- Plugins JS Ends-->
			<!-- Theme js-->
			<script src="<?= base_url('assets/backend') ?>/js/script.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/scriptku.js"></script>
			<script src="<?= base_url('assets/backend') ?>/js/theme-customizer/customizer.js"></script>
			<!-- login js-->
			<!-- Plugin used-->
			</body>

			</html>