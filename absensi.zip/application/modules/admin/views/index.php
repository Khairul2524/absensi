<div class="page-body">
	<div class="container-fluid">
		<div class="page-header">
			<div class="row">
				<div class="col-sm-6">
					<h3>Dashbaord</h3>

				</div>

			</div>
		</div>
	</div>
	<!-- Container-fluid starts-->
	<div class="container-fluid">
		<div class="row starter-main">
			<div class="col-sm-12">
				<div class="card">
				</div>
			</div>

		</div>
	</div>
	<!-- Container-fluid Ends-->
</div>